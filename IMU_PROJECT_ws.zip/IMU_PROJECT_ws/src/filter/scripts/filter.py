#!/usr/bin/env python
import rospy 
from std_msgs.msg import float32

def kalman_filter(yaw_angle):
x, p = initialize()
x, p = predict(x, p)
z = yaw_angle
 x, p = update(x, p, z) 
 yaw_angle.data =x
def predict(x, p):
 q = 2
 x = x                   
 p = p + q       
   return x, p
 def initialize():
    x = 100
    p = 7
    return x, p
    
 rospy.loginfo("yaw_angle",yaw_angle.data)
 
 
 
 
 
 def listener():
 rospy.init_node("filter",anonymous=false)
 rospy.subscriber("YAW_ANGLE_msg",float32,kalman_filter)
 rospy.spin()
 
 
 if __name__ == '__main__':
 listener()
 
